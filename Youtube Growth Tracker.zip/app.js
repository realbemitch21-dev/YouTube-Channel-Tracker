(function () {
  const STORAGE_KEY = "youtube-channel-snapshots:v1";
  const API_KEY_STORAGE_KEY = "youtube-channel-tracker-api-key:v1";
  const THEME_STORAGE_KEY = "youtube-channel-tracker-theme:v1";

  const searchForm = document.querySelector("#searchForm");
  const form = document.querySelector("#snapshotForm");
  const searchDateInput = document.querySelector("#searchSnapshotDate");
  const dateInput = document.querySelector("#snapshotDate");
  const searchInput = document.querySelector("#channelSearch");
  const apiKeyInput = document.querySelector("#apiKeyInput");
  const searchStatus = document.querySelector("#searchStatus");
  const searchResults = document.querySelector("#searchResults");
  const htmlInput = document.querySelector("#channelHtml");
  const channelFilter = document.querySelector("#channelFilter");
  const rows = document.querySelector("#snapshotRows");
  const overview = document.querySelector("#channelOverview");
  const clearBtn = document.querySelector("#clearBtn");
  const exportBtn = document.querySelector("#exportBtn");
  const importFile = document.querySelector("#importFile");
  const htmlDialog = document.querySelector("#htmlDialog");
  const htmlViewer = document.querySelector("#htmlViewer");
  const htmlPreview = document.querySelector("#htmlPreview");
  const closeHtmlBtn = document.querySelector("#closeHtmlBtn");
  const dialogTitle = document.querySelector("#dialogTitle");
  const modeButtons = document.querySelectorAll("[data-mode]");
  const viewModeButtons = document.querySelectorAll("[data-view-mode]");
  const themeBtn = document.querySelector("#themeBtn");

  let snapshots = loadSnapshots();

  const today = new Date().toISOString().slice(0, 10);
  dateInput.value = today;
  searchDateInput.value = today;
  apiKeyInput.value = localStorage.getItem(API_KEY_STORAGE_KEY) || "";
  applyTheme(localStorage.getItem(THEME_STORAGE_KEY) || "light");

  modeButtons.forEach((button) => {
    button.addEventListener("click", () => setMode(button.dataset.mode));
  });

  viewModeButtons.forEach((button) => {
    button.addEventListener("click", () => setViewMode(button.dataset.viewMode));
  });

  themeBtn.addEventListener("click", () => {
    const nextTheme = document.body.dataset.theme === "dark" ? "light" : "dark";
    applyTheme(nextTheme);
  });

  searchForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    localStorage.setItem(API_KEY_STORAGE_KEY, apiKeyInput.value.trim());
    await searchChannels(searchInput.value.trim());
  });

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    const html = htmlInput.value.trim();
    if (!html) return;

    const parsed = parseChannelHtml(html);
    const snapshot = {
      id: crypto.randomUUID(),
      date: dateInput.value,
      savedAt: new Date().toISOString(),
      sourceType: "html",
      sourceHtml: html,
      sourceLength: html.length,
      ...parsed,
    };

    snapshots.push(snapshot);
    saveSnapshots();
    htmlInput.value = "";
    render();
    channelFilter.value = "all";
    render();
  });

  channelFilter.addEventListener("change", render);

  rows.addEventListener("click", (event) => {
    const deleteButton = event.target.closest("[data-delete-id]");
    const viewButton = event.target.closest("[data-view-id]");

    if (viewButton) {
      viewSnapshotHtml(viewButton.dataset.viewId);
      return;
    }

    if (deleteButton) {
      snapshots = snapshots.filter((snapshot) => snapshot.id !== deleteButton.dataset.deleteId);
      saveSnapshots();
      render();
    }
  });

  searchResults.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-save-result]");
    if (!button) return;
    const result = JSON.parse(button.dataset.saveResult);
    button.disabled = true;
    button.textContent = "Saving...";
    try {
      await saveSearchResult(result);
    } finally {
      button.disabled = false;
      button.textContent = "Save Snapshot";
    }
  });

  closeHtmlBtn.addEventListener("click", () => {
    htmlDialog.close();
    htmlPreview.removeAttribute("srcdoc");
  });

  clearBtn.addEventListener("click", () => {
    if (!snapshots.length) return;
    if (!confirm("Delete all saved channel snapshots from this browser?")) return;
    snapshots = [];
    saveSnapshots();
    render();
  });

  exportBtn.addEventListener("click", () => {
    const blob = new Blob([JSON.stringify(snapshots, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = `youtube-channel-snapshots-${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
  });

  importFile.addEventListener("change", async () => {
    const file = importFile.files[0];
    if (!file) return;

    try {
      const imported = JSON.parse(await file.text());
      if (!Array.isArray(imported)) throw new Error("Snapshot file must contain an array.");
      snapshots = mergeSnapshots(snapshots, imported);
      saveSnapshots();
      render();
    } catch (error) {
      alert(`Import failed: ${error.message}`);
    } finally {
      importFile.value = "";
    }
  });

  render();

  function setMode(mode) {
    const useSearch = mode === "search";
    searchForm.classList.toggle("hidden", !useSearch);
    form.classList.toggle("hidden", useSearch);
    modeButtons.forEach((button) => {
      button.classList.toggle("active", button.dataset.mode === mode);
    });
  }

  function setViewMode(mode) {
    const usePreview = mode === "preview";
    htmlPreview.classList.toggle("hidden", !usePreview);
    htmlViewer.classList.toggle("hidden", usePreview);
    viewModeButtons.forEach((button) => {
      button.classList.toggle("active", button.dataset.viewMode === mode);
    });
  }

  function applyTheme(theme) {
    document.body.dataset.theme = theme;
    localStorage.setItem(THEME_STORAGE_KEY, theme);
    themeBtn.querySelector("span").textContent = theme === "dark" ? "L" : "D";
    themeBtn.title = theme === "dark" ? "Switch to light mode" : "Switch to dark mode";
    themeBtn.setAttribute("aria-label", themeBtn.title);
  }

  async function searchChannels(query) {
    searchStatus.textContent = "";
    searchResults.innerHTML = "";
    if (!query) return;

    searchStatus.textContent = "Searching...";
    try {
      const apiKey = apiKeyInput.value.trim();
      const direct = directChannelFromQuery(query);
      if (apiKey && direct) {
        const channel = await fetchChannelWithYouTubeApi(direct, apiKey);
        renderSearchResults([channel]);
        searchStatus.textContent = "Found 1 channel with the YouTube API.";
        return;
      }

      if (apiKey) {
        const results = await searchWithYouTubeApi(query, apiKey);
        renderSearchResults(results);
        searchStatus.textContent = results.length ? `Found ${results.length} channel${results.length === 1 ? "" : "s"} with the YouTube API.` : "No channels found.";
        return;
      }

      if (direct) {
        const channel = await fetchChannelByHandleOrId(direct);
        renderSearchResults([channel]);
        searchStatus.textContent = "Found 1 channel with the public fallback.";
        return;
      }

      const results = await searchViaOperationalApi(query);
      renderSearchResults(results);
      searchStatus.textContent = results.length ? `Found ${results.length} channel${results.length === 1 ? "" : "s"} with the public fallback.` : "No channels found.";
    } catch (error) {
      searchStatus.textContent = `Search failed: ${error.message}. Add a YouTube Data API key for reliable search, or use Paste HTML.`;
    }
  }

  function directChannelFromQuery(query) {
    const trimmed = query.trim();
    if (/^https?:\/\//i.test(trimmed)) {
      try {
        const url = new URL(trimmed);
        const path = url.pathname.split("/").filter(Boolean);
        const handle = path.find((part) => part.startsWith("@"));
        const channelIndex = path.findIndex((part) => part.toLowerCase() === "channel");
        if (handle) return { kind: "handle", value: handle };
        if (channelIndex >= 0 && path[channelIndex + 1]) return { kind: "id", value: path[channelIndex + 1] };
      } catch {
        return null;
      }
    }
    if (trimmed.startsWith("@")) return { kind: "handle", value: trimmed };
    if (/^UC[\w-]{20,}$/i.test(trimmed)) return { kind: "id", value: trimmed };
    return null;
  }

  async function searchViaOperationalApi(query) {
    const searchPath = `search?part=snippet&type=channel&q=${encodeURIComponent(query)}`;
    const data = await fetchFirstJson([
      `https://yt.lemnoslife.com/${searchPath}`,
      `https://yt.lemnoslife.com/noKey/${searchPath}`,
    ]);
    const items = Array.isArray(data.items) ? data.items : [];
    return items.slice(0, 8).map((item) => {
      const snippet = item.snippet || {};
      const channelId = item.id?.channelId || item.id || snippet.channelId || "";
      return normalizeApiChannel({
        channelId,
        channelName: snippet.channelTitle || snippet.title || "Unknown channel",
        handle: snippet.customUrl || "",
        subscribers: null,
        videos: null,
        views: null,
        sourceJson: item,
      });
    });
  }

  async function searchWithYouTubeApi(query, apiKey) {
    const url = new URL("https://www.googleapis.com/youtube/v3/search");
    url.searchParams.set("part", "snippet");
    url.searchParams.set("type", "channel");
    url.searchParams.set("maxResults", "8");
    url.searchParams.set("q", query);
    url.searchParams.set("key", apiKey);

    const data = await fetchJson(url.toString());
    const ids = (data.items || []).map((item) => item.id?.channelId).filter(Boolean);
    if (!ids.length) return [];
    return fetchChannelDetailsWithYouTubeApi(ids, apiKey);
  }

  async function fetchChannelWithYouTubeApi(identifier, apiKey) {
    if (identifier.kind === "id") {
      const channels = await fetchChannelDetailsWithYouTubeApi([identifier.value], apiKey);
      if (!channels[0]) throw new Error("channel was not found");
      return channels[0];
    }

    let item = null;
    for (const handle of [identifier.value, identifier.value.replace(/^@/, "")]) {
      const url = new URL("https://www.googleapis.com/youtube/v3/channels");
      url.searchParams.set("part", "snippet,statistics");
      url.searchParams.set("forHandle", handle);
      url.searchParams.set("key", apiKey);

      const data = await fetchJson(url.toString());
      item = (data.items || [])[0];
      if (item) break;
    }

    if (!item) throw new Error("channel was not found");
    return normalizeYouTubeApiChannel(item);
  }

  async function fetchChannelDetailsWithYouTubeApi(ids, apiKey) {
    const url = new URL("https://www.googleapis.com/youtube/v3/channels");
    url.searchParams.set("part", "snippet,statistics");
    url.searchParams.set("id", ids.join(","));
    url.searchParams.set("key", apiKey);

    const data = await fetchJson(url.toString());
    return (data.items || []).map(normalizeYouTubeApiChannel);
  }

  function normalizeYouTubeApiChannel(item) {
    const snippet = item.snippet || {};
    const stats = item.statistics || {};
    const handle = snippet.customUrl || "";
    return normalizeApiChannel({
      channelId: item.id || "",
      channelName: snippet.title || "Unknown channel",
      handle: handle.startsWith("@") ? handle : handle ? `@${handle}` : "",
      subscribers: numberFromApi(stats.subscriberCount),
      videos: numberFromApi(stats.videoCount),
      views: numberFromApi(stats.viewCount),
      savedVideos: [],
      sourceJson: item,
    });
  }

  async function fetchRecentVideosWithYouTubeApi(channelId, apiKey) {
    if (!channelId || !apiKey) return [];

    const url = new URL("https://www.googleapis.com/youtube/v3/search");
    url.searchParams.set("part", "snippet");
    url.searchParams.set("channelId", channelId);
    url.searchParams.set("type", "video");
    url.searchParams.set("order", "date");
    url.searchParams.set("maxResults", "25");
    url.searchParams.set("key", apiKey);

    const data = await fetchJson(url.toString());
    const videos = (data.items || []).map((item) => {
      const snippet = item.snippet || {};
      const thumbnails = snippet.thumbnails || {};
      return {
        videoId: item.id?.videoId || "",
        title: snippet.title || "Untitled video",
        description: snippet.description || "",
        publishedAt: snippet.publishedAt || "",
        viewCount: null,
        thumbnail: thumbnails.high?.url || thumbnails.medium?.url || thumbnails.default?.url || "",
      };
    });

    return addVideoStatsWithYouTubeApi(videos, apiKey);
  }

  async function addVideoStatsWithYouTubeApi(videos, apiKey) {
    const ids = videos.map((video) => video.videoId).filter(Boolean);
    if (!ids.length) return videos;

    const url = new URL("https://www.googleapis.com/youtube/v3/videos");
    url.searchParams.set("part", "statistics");
    url.searchParams.set("id", ids.join(","));
    url.searchParams.set("key", apiKey);

    const data = await fetchJson(url.toString());
    const statsById = new Map(
      (data.items || []).map((item) => [item.id, numberFromApi(item.statistics?.viewCount)]),
    );

    return videos.map((video) => ({
      ...video,
      viewCount: statsById.has(video.videoId) ? statsById.get(video.videoId) : null,
    }));
  }

  async function fetchChannelByHandleOrId(identifier) {
    const query = identifier.kind === "handle" ? handleQueries(identifier.value) : [`id=${encodeURIComponent(identifier.value)}`];
    let data = null;
    let lastError = null;
    for (const candidate of query) {
      try {
        const channelPath = `channels?part=snippet,statistics&${candidate}`;
        data = await fetchFirstJson([
          `https://yt.lemnoslife.com/${channelPath}`,
          `https://yt.lemnoslife.com/noKey/${channelPath}`,
        ]);
        break;
      } catch (error) {
        lastError = error;
      }
    }
    if (!data) throw lastError || new Error("channel was not found");
    const item = Array.isArray(data.items) ? data.items[0] : data;
    if (!item) throw new Error("channel was not found");
    const snippet = item.snippet || {};
    const stats = item.statistics || {};
    return normalizeApiChannel({
      channelId: item.id || item.channelId || identifier.value,
      channelName: snippet.title || item.title || identifier.value,
      handle: snippet.customUrl || (identifier.kind === "handle" ? identifier.value : ""),
      subscribers: numberFromApi(stats.subscriberCount),
      videos: numberFromApi(stats.videoCount),
      views: numberFromApi(stats.viewCount),
      sourceJson: item,
    });
  }

  function handleQueries(value) {
    const withoutAt = value.replace(/^@/, "");
    return [`handle=${encodeURIComponent(value)}`, `handle=${encodeURIComponent(withoutAt)}`];
  }

  async function fetchJson(url) {
    const response = await fetch(url);
    if (!response.ok) throw new Error(`request failed (${response.status})`);
    return response.json();
  }

  async function fetchFirstJson(urls) {
    let lastError = null;
    for (const url of urls) {
      try {
        return await fetchJson(url);
      } catch (error) {
        lastError = error;
      }
    }
    throw lastError || new Error("request failed");
  }

  function normalizeApiChannel(channel) {
    return {
      channelKey: channel.channelId || channel.handle || channel.channelName,
      channelName: channel.channelName || "Unknown channel",
      handle: channel.handle || "",
      channelId: channel.channelId || "",
      subscribers: channel.subscribers,
      videos: channel.videos,
      views: channel.views,
      sourceJson: channel.sourceJson || null,
    };
  }

  function numberFromApi(value) {
    const number = Number(value);
    return Number.isFinite(number) ? number : null;
  }

  function renderSearchResults(results) {
    if (!results.length) {
      searchResults.innerHTML = "";
      return;
    }

    searchResults.innerHTML = results
      .map(
        (result) => `<article class="result-card">
          <div>
            <strong>${escapeHtml(result.channelName)}</strong>
            <span>${escapeHtml(result.handle || result.channelId || "No channel id found")}</span>
          </div>
          <dl>
            <div><dt>Subscribers</dt><dd>${formatNumber(result.subscribers)}</dd></div>
            <div><dt>Videos</dt><dd>${formatNumber(result.videos)}</dd></div>
            <div><dt>Views</dt><dd>${formatNumber(result.views)}</dd></div>
          </dl>
          <button class="secondary-button" type="button" data-save-result="${escapeHtml(JSON.stringify(result))}">Save Snapshot</button>
        </article>`,
      )
      .join("");
  }

  async function saveSearchResult(result) {
    let detailed = result;
    const apiKey = apiKeyInput.value.trim();
    if (apiKey && result.channelId) {
      try {
        const channels = await fetchChannelDetailsWithYouTubeApi([result.channelId], apiKey);
        detailed = channels[0] || result;
      } catch {
        detailed = result;
      }
    } else if (result.channelId) {
      try {
        detailed = await fetchChannelByHandleOrId({ kind: "id", value: result.channelId });
      } catch {
        detailed = result;
      }
    }

    if (apiKey && detailed.channelId) {
      try {
        detailed = {
          ...detailed,
          savedVideos: await fetchRecentVideosWithYouTubeApi(detailed.channelId, apiKey),
        };
      } catch {
        detailed = {
          ...detailed,
          savedVideos: detailed.savedVideos || [],
        };
      }
    }

    const snapshot = {
      id: crypto.randomUUID(),
      date: searchDateInput.value,
      savedAt: new Date().toISOString(),
      sourceType: "search",
      sourceHtml: "",
      sourceLength: 0,
      ...detailed,
    };

    snapshots.push(snapshot);
    saveSnapshots();
    render();
    channelFilter.value = "all";
    render();
    searchStatus.textContent = `Saved ${snapshot.channelName}.`;
  }

  function viewSnapshotHtml(id) {
    const snapshot = snapshots.find((item) => item.id === id);
    if (!snapshot) return;
    dialogTitle.textContent = `${snapshot.channelName} - ${snapshot.date}`;
    const hasHtml = Boolean(snapshot.sourceHtml);
    const source = snapshot.sourceHtml || JSON.stringify(snapshot.sourceJson || snapshot, null, 2);
    htmlViewer.value = source;
    htmlPreview.srcdoc = hasHtml ? source : channelPreview(snapshot);
    setViewMode("preview");
    htmlDialog.showModal();
  }

  function channelPreview(snapshot) {
    const source = snapshot.sourceJson || {};
    const snippet = source.snippet || {};
    const thumbnails = snippet.thumbnails || {};
    const thumbnail = thumbnails.high?.url || thumbnails.medium?.url || thumbnails.default?.url || "";
    const channelUrl = snapshot.handle
      ? `https://www.youtube.com/${snapshot.handle}`
      : snapshot.channelId
        ? `https://www.youtube.com/channel/${snapshot.channelId}`
        : "";
    const description = snippet.description || "No description saved for this snapshot.";
    const publishedAt = snippet.publishedAt ? new Date(snippet.publishedAt).toLocaleDateString() : "n/a";
    const savedVideos = Array.isArray(snapshot.savedVideos) ? snapshot.savedVideos : [];
    const videoCards = savedVideos.length
      ? savedVideos.map(videoCard).join("")
      : `<p class="empty-videos">No videos were saved with this snapshot. Save the channel again with your API key active, or paste channel HTML that includes video cards.</p>`;

    return `<!doctype html><html><head><meta charset="UTF-8"><style>
      :root { color-scheme: light; font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
      * { box-sizing: border-box; }
      body { margin: 0; color: #202124; background: #f7f7f4; }
      main { min-height: 100vh; padding: 28px; }
      .hero { display: grid; grid-template-columns: 120px minmax(0, 1fr); gap: 18px; align-items: center; }
      img { width: 120px; height: 120px; border-radius: 50%; object-fit: cover; background: #e7e9e4; }
      h1 { margin: 0; font-size: clamp(2rem, 6vw, 4.5rem); line-height: 0.95; letter-spacing: 0; overflow-wrap: anywhere; }
      .handle { margin: 8px 0 0; color: #687078; font-weight: 800; overflow-wrap: anywhere; }
      .stats { display: grid; grid-template-columns: repeat(3, minmax(120px, 1fr)); gap: 10px; margin: 26px 0; }
      .metric { border: 1px solid #d9ddd6; border-radius: 8px; padding: 14px; background: #fff; }
      .metric span { display: block; color: #687078; font-size: 0.72rem; font-weight: 900; text-transform: uppercase; }
      .metric strong { display: block; margin-top: 7px; font-size: 1.55rem; overflow-wrap: anywhere; }
      .details { display: grid; gap: 12px; border-top: 1px solid #d9ddd6; padding-top: 18px; color: #34383d; line-height: 1.5; }
      .details p { margin: 0; white-space: pre-wrap; overflow-wrap: anywhere; }
      .videos-head { display: flex; align-items: end; justify-content: space-between; gap: 12px; margin: 30px 0 14px; border-top: 1px solid #d9ddd6; padding-top: 22px; }
      .videos-head h2 { margin: 0; font-size: 1.35rem; }
      .videos-head span { color: #687078; font-weight: 800; }
      .video-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(210px, 1fr)); gap: 16px; }
      .video-card { color: inherit; text-decoration: none; }
      .thumb { display: block; width: 100%; aspect-ratio: 16 / 9; border-radius: 8px; object-fit: cover; background: #e7e9e4; }
      .video-card strong { display: block; margin-top: 9px; line-height: 1.25; overflow-wrap: anywhere; }
      .video-meta { display: flex; flex-wrap: wrap; gap: 5px 10px; margin-top: 6px; color: #687078; font-size: 0.86rem; font-weight: 700; }
      .empty-videos { margin: 0; border: 1px solid #d9ddd6; border-radius: 8px; padding: 16px; background: #fff; color: #687078; }
      a { color: #285f9f; font-weight: 800; }
      @media (max-width: 620px) {
        main { padding: 18px; }
        .hero { grid-template-columns: 1fr; }
        .stats { grid-template-columns: 1fr; }
      }
    </style></head><body><main>
      <section class="hero">
        ${thumbnail ? `<img src="${escapeHtml(thumbnail)}" alt="">` : ""}
        <div>
          <h1>${escapeHtml(snapshot.channelName)}</h1>
          <p class="handle">${escapeHtml(snapshot.handle || snapshot.channelId || "No channel id saved")}</p>
        </div>
      </section>
      <section class="stats" aria-label="Saved channel stats">
        <article class="metric"><span>Subscribers</span><strong>${formatNumber(snapshot.subscribers)}</strong></article>
        <article class="metric"><span>Videos</span><strong>${formatNumber(snapshot.videos)}</strong></article>
        <article class="metric"><span>Views</span><strong>${formatNumber(snapshot.views)}</strong></article>
      </section>
      <section class="details">
        <p><strong>Snapshot date:</strong> ${escapeHtml(snapshot.date)}</p>
        <p><strong>Created:</strong> ${escapeHtml(publishedAt)}</p>
        ${channelUrl ? `<p><a href="${escapeHtml(channelUrl)}" target="_blank" rel="noreferrer">Open channel on YouTube</a></p>` : ""}
        <p>${escapeHtml(description)}</p>
      </section>
      <section>
        <div class="videos-head">
          <h2>Videos saved in this snapshot</h2>
          <span>${formatNumber(savedVideos.length)}</span>
        </div>
        <div class="video-grid">${videoCards}</div>
      </section>
    </main></body></html>`;
  }

  function videoCard(video) {
    const url = video.videoId ? `https://www.youtube.com/watch?v=${video.videoId}` : "";
    const date = video.publishedAt ? new Date(video.publishedAt).toLocaleDateString() : "";
    const views = typeof video.viewCount === "number" ? `${formatNumber(video.viewCount)} views` : "";
    const inner = `
      ${video.thumbnail ? `<img class="thumb" src="${escapeHtml(video.thumbnail)}" alt="">` : `<span class="thumb"></span>`}
      <strong>${escapeHtml(video.title || "Untitled video")}</strong>
      ${date || views ? `<div class="video-meta">${views ? `<span>${escapeHtml(views)}</span>` : ""}${date ? `<span>${escapeHtml(date)}</span>` : ""}</div>` : ""}
    `;
    return url ? `<a class="video-card" href="${escapeHtml(url)}" target="_blank" rel="noreferrer">${inner}</a>` : `<article class="video-card">${inner}</article>`;
  }

  function parseChannelHtml(html) {
    const text = decodeEntities(stripTags(html)).replace(/\s+/g, " ").trim();
    const rawText = decodeEntities(html).replace(/\\u0026/g, "&").replace(/\\"/g, '"');
    const title = findFirst(html, [
      /<meta[^>]+property=["']og:title["'][^>]+content=["']([^"']+)["']/i,
      /<title[^>]*>([^<]+)<\/title>/i,
      /"title"\s*:\s*"([^"]+)"/i,
    ]);
    const channelName = cleanChannelName(title || findNear(text, /(?:^|\s)([A-Z][^|]{2,80})\s+(@[\w.-]+)/));
    const handle = findFirst(html, [/"canonicalBaseUrl"\s*:\s*"\/(@[^"]+)"/i, /"webCommandMetadata"[^}]+url"\s*:\s*"\/(@[^"]+)"/i]) || findFirst(text, [/@[\w.-]{2,}/]);
    const channelId = findFirst(html, [/"channelId"\s*:\s*"([^"]+)"/i, /"externalId"\s*:\s*"([^"]+)"/i]);
    const subscribers = parseStat(text, rawText, ["subscribers", "subscriber"]);
    const videos = parseStat(text, rawText, ["videos", "video"]);
    const views = parseStat(text, rawText, ["views", "view"]);
    const savedVideos = parseVideosFromHtml(rawText);
    const channelKey = channelId || handle || channelName || `unknown-${Date.now()}`;

    return {
      channelKey,
      channelName: channelName || handle || "Unknown channel",
      handle: handle || "",
      channelId: channelId || "",
      subscribers,
      videos,
      views,
      savedVideos,
    };
  }

  function parseVideosFromHtml(rawText) {
    const videos = [];
    const seen = new Set();
    const videoPattern = /"videoId"\s*:\s*"([^"]+)"[\s\S]{0,2500}?"title"\s*:\s*\{[\s\S]{0,300}?"text"\s*:\s*"([^"]+)"/g;
    let match = videoPattern.exec(rawText);

    while (match && videos.length < 25) {
      const videoId = match[1];
      if (!seen.has(videoId)) {
        seen.add(videoId);
        videos.push({
          videoId,
          title: decodeEscapedJson(match[2]),
          description: "",
          publishedAt: "",
          viewCount: parseVideoViewsNear(rawText, match.index),
          thumbnail: `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
        });
      }
      match = videoPattern.exec(rawText);
    }

    return videos;
  }

  function parseVideoViewsNear(rawText, index) {
    const nearby = rawText.slice(index, index + 4000);
    const match = nearby.match(/([\\d,.]+)\\s*([KMBTkmbt]?)\\s+views\\b/i) || nearby.match(/"viewCountText"[\s\S]{0,300}?"text"\s*:\s*"([\\d,.]+)\\s*([KMBTkmbt]?)\\s+views"/i);
    return match ? normalizeNumber(match[1], match[2]) : null;
  }

  function decodeEscapedJson(value) {
    return decodeEntities(String(value).replace(/\\"/g, '"').replace(/\\u0026/g, "&"));
  }

  function stripTags(html) {
    return html
      .replace(/<script[\s\S]*?<\/script>/gi, " ")
      .replace(/<style[\s\S]*?<\/style>/gi, " ")
      .replace(/<[^>]*>/g, " ");
  }

  function decodeEntities(value) {
    const textarea = document.createElement("textarea");
    textarea.innerHTML = value;
    return textarea.value;
  }

  function findFirst(value, patterns) {
    for (const pattern of patterns) {
      const match = value.match(pattern);
      if (match) return decodeEntities(match[1]).replace(/\\u0026/g, "&").trim();
    }
    return "";
  }

  function findNear(text, pattern) {
    const match = text.match(pattern);
    return match ? match[1].trim() : "";
  }

  function cleanChannelName(value) {
    return value
      .replace(/\s*-\s*YouTube\s*$/i, "")
      .replace(/\s*-\s*Home\s*$/i, "")
      .replace(/\s*@[\w.-]+\s*$/, "")
      .trim();
  }

  function parseStat(text, rawText, labels) {
    for (const label of labels) {
      const afterPattern = new RegExp(`([\\d,.]+)\\s*([KMBTkmbt]?)\\s+${label}\\b`, "i");
      const beforePattern = new RegExp(`${label}\\s*[:\\-]?\\s*([\\d,.]+)\\s*([KMBTkmbt]?)`, "i");
      const compactPattern = new RegExp(`"simpleText"\\s*:\\s*"([\\d,.]+)\\s*([KMBTkmbt]?)\\s+${label}"`, "i");
      const accessibilityPattern = new RegExp(`"accessibilityData"\\s*:\\s*\\{\\s*"label"\\s*:\\s*"([\\d,.]+)\\s*([KMBTkmbt]?)\\s+${label}"`, "i");
      const match =
        text.match(afterPattern) ||
        text.match(beforePattern) ||
        rawText.match(compactPattern) ||
        rawText.match(accessibilityPattern);
      if (match) return normalizeNumber(match[1], match[2]);
    }
    return null;
  }

  function normalizeNumber(value, suffix) {
    const number = Number.parseFloat(String(value).replace(/,/g, ""));
    if (Number.isNaN(number)) return null;
    const multipliers = { k: 1_000, m: 1_000_000, b: 1_000_000_000, t: 1_000_000_000_000 };
    return Math.round(number * (multipliers[String(suffix).toLowerCase()] || 1));
  }

  function loadSnapshots() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    } catch {
      return [];
    }
  }

  function saveSnapshots() {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(snapshots));
  }

  function render() {
    snapshots.sort((a, b) => a.date.localeCompare(b.date) || a.savedAt.localeCompare(b.savedAt));
    renderFilter();
    renderOverview();
    renderRows();
  }

  function renderFilter() {
    const selected = channelFilter.value || "all";
    const channels = [...new Map(snapshots.map((snapshot) => [snapshot.channelKey, snapshot])).values()];
    channelFilter.innerHTML = `<option value="all">All channels</option>${channels
      .map((channel) => `<option value="${escapeHtml(channel.channelKey)}">${escapeHtml(channel.channelName)}</option>`)
      .join("")}`;
    channelFilter.value = channels.some((channel) => channel.channelKey === selected) ? selected : "all";
  }

  function visibleSnapshots() {
    const selected = channelFilter.value;
    return selected === "all" ? snapshots : snapshots.filter((snapshot) => snapshot.channelKey === selected);
  }

  function renderOverview() {
    const visible = visibleSnapshots();
    const latestByChannel = latestSnapshots(visible);
    const totals = latestByChannel.reduce(
      (sum, snapshot) => ({
        subscribers: sum.subscribers + (snapshot.subscribers || 0),
        videos: sum.videos + (snapshot.videos || 0),
        views: sum.views + (snapshot.views || 0),
      }),
      { subscribers: 0, videos: 0, views: 0 },
    );

    overview.innerHTML = [
      metric("Snapshots", formatNumber(visible.length), `${latestByChannel.length} channel${latestByChannel.length === 1 ? "" : "s"}`),
      metric("Subscribers", formatNumber(totals.subscribers), "latest saved totals"),
      metric("Videos", formatNumber(totals.videos), "latest saved totals"),
      metric("Views", formatNumber(totals.views), "latest saved totals"),
    ].join("");
  }

  function metric(label, value, detail) {
    return `<article class="metric"><span>${label}</span><strong>${value}</strong><small>${detail}</small></article>`;
  }

  function renderRows() {
    const visible = visibleSnapshots();
    if (!visible.length) {
      rows.innerHTML = `<tr><td colspan="8" class="empty-state">Paste a channel page HTML snapshot to start tracking changes over time.</td></tr>`;
      return;
    }

    const previousByChannel = new Map();
    rows.innerHTML = visible
      .map((snapshot) => {
        const previous = previousByChannel.get(snapshot.channelKey);
        previousByChannel.set(snapshot.channelKey, snapshot);
        return row(snapshot, previous);
      })
      .reverse()
      .join("");
  }

  function row(snapshot, previous) {
    return `<tr>
      <td>${escapeHtml(snapshot.date)}</td>
      <td><div class="channel-name">${escapeHtml(snapshot.channelName)}</div><div class="muted">${escapeHtml(snapshot.handle || snapshot.channelId || "No id found")}</div></td>
      <td>${formatNumber(snapshot.subscribers)}</td>
      <td>${formatNumber(snapshot.videos)}</td>
      <td>${formatNumber(snapshot.views)}</td>
      <td>${formatNumber(Array.isArray(snapshot.savedVideos) ? snapshot.savedVideos.length : 0)}</td>
      <td>${growthCell(snapshot, previous)}</td>
      <td class="row-actions">
        <button class="mini-button" data-view-id="${escapeHtml(snapshot.id)}" type="button">View</button>
        <button class="delete-button" data-delete-id="${escapeHtml(snapshot.id)}" type="button" title="Delete snapshot" aria-label="Delete snapshot">x</button>
      </td>
    </tr>`;
  }

  function growthCell(snapshot, previous) {
    if (!previous) return `<span class="muted">baseline</span>`;
    const subscriberGrowth = diff(snapshot.subscribers, previous.subscribers);
    const videoGrowth = diff(snapshot.videos, previous.videos);
    const viewGrowth = diff(snapshot.views, previous.views);
    return [
      growthLine("Subs", subscriberGrowth),
      growthLine("Videos", videoGrowth),
      growthLine("Views", viewGrowth),
    ].join("<br>");
  }

  function growthLine(label, value) {
    if (value === null) return `<span class="muted">${label}: n/a</span>`;
    const className = value > 0 ? "growth-positive" : "growth-flat";
    const prefix = value > 0 ? "+" : "";
    return `<span class="${className}">${label}: ${prefix}${formatNumber(value)}</span>`;
  }

  function diff(current, previous) {
    if (typeof current !== "number" || typeof previous !== "number") return null;
    return current - previous;
  }

  function latestSnapshots(list) {
    const latest = new Map();
    for (const snapshot of list) latest.set(snapshot.channelKey, snapshot);
    return [...latest.values()];
  }

  function formatNumber(value) {
    if (typeof value !== "number") return "n/a";
    return new Intl.NumberFormat().format(value);
  }

  function mergeSnapshots(current, imported) {
    const byId = new Map(current.map((snapshot) => [snapshot.id, snapshot]));
    for (const snapshot of imported) {
      if (!snapshot || typeof snapshot !== "object") continue;
      const id = snapshot.id || crypto.randomUUID();
      byId.set(id, {
        id,
        date: snapshot.date || new Date().toISOString().slice(0, 10),
        savedAt: snapshot.savedAt || new Date().toISOString(),
        channelKey: snapshot.channelKey || snapshot.channelId || snapshot.handle || crypto.randomUUID(),
        channelName: snapshot.channelName || "Unknown channel",
        handle: snapshot.handle || "",
        channelId: snapshot.channelId || "",
        subscribers: numberOrNull(snapshot.subscribers),
        videos: numberOrNull(snapshot.videos),
        views: numberOrNull(snapshot.views),
        savedVideos: normalizeSavedVideos(snapshot.savedVideos),
        sourceType: snapshot.sourceType || (snapshot.sourceHtml ? "html" : "import"),
        sourceHtml: snapshot.sourceHtml || "",
        sourceJson: snapshot.sourceJson || null,
        sourceLength: numberOrNull(snapshot.sourceLength),
      });
    }
    return [...byId.values()];
  }

  function numberOrNull(value) {
    return typeof value === "number" && Number.isFinite(value) ? value : null;
  }

  function normalizeSavedVideos(videos) {
    if (!Array.isArray(videos)) return [];
    return videos.map((video) => ({
      videoId: video.videoId || "",
      title: video.title || "Untitled video",
      description: video.description || "",
      publishedAt: video.publishedAt || "",
      viewCount: numberOrNull(video.viewCount),
      thumbnail: video.thumbnail || "",
    }));
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;")
      .replace(/'/g, "&#039;");
  }
})();
